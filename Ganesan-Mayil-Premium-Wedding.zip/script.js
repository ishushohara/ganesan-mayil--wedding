
const target=new Date('2026-11-13T05:30:00').getTime();
setInterval(()=>{
let now=new Date().getTime();
let d=Math.floor((target-now)/(1000*60*60*24));
document.getElementById('timer').innerHTML=d+' Days Remaining';
},1000);
